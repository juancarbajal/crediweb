<?php
Zend_Loader::loadClass('Quipu_View_Helper_FormElement');
/**
 * @category Quipu
 * @package Quipu_View_Helper
 * @copyright Copyright (c) 2008 Juan Carbajal
 * @license BSD License
 */
class Quipu_View_Helper_Input extends Quipu_View_Helper_FormElement{
  /**
   * Funci�n que genera una marca INPUT
   * @param string $name Nombre de la marca
   * @param string $type Tipo de marca INPUT
   * @param array $options Opciones adicionales de la marca INPUT
   * @uses Zend_View_Helper_FormElement::getStrOptions()
   * @return string Marca INPUT
   */
  function input($name,$type=null,$options=null){
    return "<input ".(($type!=null)?"type='$type'":"")." name='$name' id='$name'  ".$this->getStrOptions($options)."/>";
  }	
}
?>