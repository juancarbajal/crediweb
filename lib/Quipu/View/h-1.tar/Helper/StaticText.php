<?php
require_once 'Zend/View/Helper/FormElement.php';
class Quipu_View_Helper_StaticText extends Zend_View_Helper_FormElement{
	function staticText($Name,$Value="",$Size=20,$Options=null){
		$Options["style"]="'background-color:#FFF3C4'";
		$Options["value"]="'$Value'";
		$Options["size"]=$Size;
		$Options["readonly"]="readonly";
		return $this->view->input($Name,"static",$Options);
	}
}
?>