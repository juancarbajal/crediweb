<?php
require_once 'Zend/View/Helper/FormElement.php';
class Quipu_View_Helper_TextMail extends Zend_View_Helper_FormElement{
	function textMail($Name,$Default="",$Reload="",$Required=false,$MaxLength=100,$Size=20,$Options=null){
		$Options['dojoType']="'EmailTextbox'";
		$Options["invalidMessage"]="'El correo es invalido.'";
		return $this->view->text($Name,$Default,$Reload,$Required,$MaxLength,$Size,$Options);
	}
}
?>