<?php
require_once 'Zend/View/Helper/FormElement.php';
class Quipu_View_Helper_Password extends Zend_View_Helper_FormElement{
	function password($Name,$Default="",$MaxLength=20,$Size=20,$Options=null){
		$Options["maxlength"]="'$MaxLength'";
		$Options["size"]="'$Size'";
		return $this->view->input($Name,"password",$Options);
	}
}
?>