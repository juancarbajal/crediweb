<?php
require_once 'Zend/View/Helper/FormElement.php';
class Quipu_View_Helper_UploadFile extends Zend_View_Helper_FormElement{
	function uploadFile($Name,$Options=null){
		return $this->view->input($Name,'file',$Options);
	}
}
?>