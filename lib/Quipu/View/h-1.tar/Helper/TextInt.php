<?php
require_once 'Zend/View/Helper/FormElement.php';
class Quipu_View_Helper_TextInt extends Zend_View_Helper_FormElement{
	function textInt($Name,$Default="",$Required=false,$MaxLength=10,$Size=20,$Options=null){
		$Options["dojoType"]="'dijit.form.NumberTextBox'";
		/*if (!isset($Options["signed"]))
			$Options["signed"]="'false'";
		$Options["trim"]="'true'";*/
		$Options["invalidMessage"]="'El valor es un n&uacute;mero entero invalido.'";
		//$Options["onKeyPress"]='"return '.$this->GetJSValidator().'.IsIntInline(event);"';		
		return $this->view->text($Name,$Default,$Required,$MaxLength,$Size,$Options);
	}
}
?>