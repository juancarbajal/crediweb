<?php
require_once 'Zend/View/Helper/FormElement.php';
class Quipu_View_Helper_TextIPv4 extends Zend_View_Helper_FormElement{
	function textIPv4($Name,$Default="",$Required=false,$MaxLength=15,$Size=20,$Options=null){
		$Options["dojoType"]="'dijit.form.ValidationTextBox'";
		$Options["regExpGen"]="'dojo.regexp.ipAddress'";
		$Options["trim"]="'true'";
		$Options["constraints"]="{allowIPv6:false,allowHybrid:false}";
		$Options["invalidMessage"]="'La IPV4 es invalida, el formato es XXX:XXX:XXX:XXX'";
		return $this->view->text($Name,$Default,$Required,$MaxLength,$Size,$Options);
	}
}
?>