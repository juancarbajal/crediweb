<?php
require_once 'Zend/View/Helper/FormElement.php';
class Quipu_View_Helper_TextFloat extends Zend_View_Helper_FormElement{
	function textFloat($Name,$Default="",$Required=false,$MaxLength=10,$Size=20,$Options=null){
		$Options["dojoType"]="'dijit.form.ValidationTextBox'";
		$Options["regExpGen"]="'dojo.number._realNumberRegexp'";//dojo.regexp.realNumber

		$Options["invalidMessage"]="'El valor es un n&uacute;mero invalido.'";
		return $this->view->text($Name,$Default,$Required,$MaxLength,$Size,$Options);
	}
}
?>