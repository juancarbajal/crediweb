<?php
Zend_Loader::loadClass('Quipu_View_Helper_FormElement');
/**
 * @category Quipu
 * @package Quipu_View_Helper
 * @copyright Copyright (c) 2008 Juan Carbajal
 * @license BSD License
 */
class Quipu_View_Helper_Hidden extends Quipu_View_Helper_FormElement{
  /**
   * Funci�n que genera una marca HIDDEN
   * @name string Nombre de la marca 
   * @uses Quipu_View_Helper_Input::input()
   * @return string Marca HIDDEN
   */
  function hidden($name,$value){
    $Options["value"]="'$value'";
    return $this->view->input($name,"hidden",$options);
  }
}
?>