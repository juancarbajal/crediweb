<?php
require_once 'Zend/View/Helper/FormElement.php';
class Quipu_View_Helper_TextTime extends Zend_View_Helper_FormElement{
	function textTime($Name,$Default="",$Required=false,$Format='HH:mm'/*,$Format='HH:mm:ss'*/,$MaxLength=8,$Size=12,$Options=null){
		$Options['dojoType']="'dijit.form.TimeTextBox'";
		$Options['trim']="'true'";
		//$Options['format']="'$Format'";
		$Options['constraints']="'{formatLength:\"short\",timePattern:\"HH:mm:ss\"}'";
		$Options["invalidMessage"]="'Hora Invalida. use HH/mm/ss.'";
		$MaxLength=strlen($Format);
		return $this->view->text($Name,$Default,$Required,$MaxLength,$Size,$Options);
	}
}
?>