<?php
require_once 'Zend/View/Helper/FormElement.php';
class Quipu_View_Helper_TextUrl extends Zend_View_Helper_FormElement{
	function textUrl($Name,$Default="",$Required=false,$MaxLength=100,$Size=20,$Options=null){
		$Options['dojoType']="'dijit.form.ValidationTextBox'";
		$Options['regExpGen']="'dojo.regexp.url'";
		$Options['trim']="'true'";
		$Options['constraints']="{scheme:true}";
		$Options["invalidMessage"]="'La URL es invalida.'";
		return $this->view->text($Name,$Default,$Required,$MaxLength,$Size,$Options);
	}
}
?>