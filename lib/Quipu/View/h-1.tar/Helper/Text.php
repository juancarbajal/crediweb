<?php
require_once 'Zend/View/Helper/FormElement.php';
class Quipu_View_Helper_Text extends Zend_View_Helper_FormElement{
	function text($Name,$Default="",$Required=false,$MaxLength=20,$Size=20,$Options=null){
		if ($MaxLength>0){$Options["maxlength"]="'$MaxLength'";}
		if ($Size>0){$Options["size"]="'$Size'";}
		if (!isset($Options["dojoType"])) $Options["dojoType"]="'dijit.form.ValidationTextBox'";
		$Options["required"]=($Required)?"'true'":"'false'";
		$Options["value"]="'$Default'";
		//$Options['missingMessage']="'* El campo es requerido'";
		$Options['invalidMessage']="'* El campo es requerido'";
		//$Options["invalidMessage"]="'El valor no es un valor valido'";
		return $this->view->input($Name,"text",$Options);
	}
}
?>
