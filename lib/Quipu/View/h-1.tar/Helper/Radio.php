<?php
require_once 'Zend/View/Helper/FormElement.php';
class Quipu_View_Helper_RadioGroup extends Zend_View_Helper_FormElement{
	function radioGroup($Name,$Labels,$Values,$Select=1,$Options=null){
		$s='';
		for ($i=0;$i<count($Labels);$i++){
			$miOpcion=$Options;
			$IsSelect=($Values[$i]==$Select)?true:false;
			$s.=$this->view->radio($Name,$Labels[$i],$Values[$i],$IsSelect,$miOpcion).'<br/>';
		}
		return $s;
	}
}
?>