<?php
require_once 'Zend/View/Helper/FormElement.php';
class Quipu_View_Helper_SelectArray extends Zend_View_Helper_FormElement{
	function selectArray($Name,$ListArray,$Select=null,$Options=null){
		foreach($ListArray as $row){
			$List[]=$row[1];
			$Values[]=$row[0];
		}
		return $this->view->select($Name,$List,$Values,$Select,$Options);
	}
}
?>