<?php
require_once 'Zend/View/Helper/FormElement.php';
class Quipu_View_Helper_TextIPv6 extends Zend_View_Helper_FormElement{
	function textIPv6($Name,$Default="",$Required=false,$MaxLength=10,$Size=20,$Options=null){
$Options["dojoType"]="'dijit.form.ValidationTextBox'";
		$Options["regExpGen"]="'dojo.regexp.ipAddress'";
		$Options["trim"]="'true'";
		$Options["constraints"]="{allowDottedDecimal:false, allowDottedHex:false, allowDottedOctal:false}";
		$Options["trim"]="'true'";
		$Options["uppercase"]="'true'";
		/*$Options["allowDottedDecimal"]="'false'";
		$Options["allowDottedHex"]="'false'";
		$Options["allowDottedOctal"]="'false'";*/
		$Options["invalidMessage"]="'La IPV6 es invalida'";
		return $this->view->text($Name,$Default,$Required,$MaxLength,$Size,$Options);
	}
}
?>