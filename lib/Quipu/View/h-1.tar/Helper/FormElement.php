<?php
Zend_Loader::loadClass('Zend_View_Helper_FormElement');
/**
 * @category Quipu
 * @package Quipu_View_Helper_FormElement
 * @copyright Copyright (c) 2008 Juan Carbajal
 * @license BSD License
 */
class Quipu_View_Helper_FormElement extends  Zend_View_Helper_FormElement{
  /**
   * Funci�n que convierte un array en atributos de un marca HTML
   * @param array $options Lista de atributos
   * @return string Cadena de atributos de una marca HTML
   */
  function getStrOptions($options){
    $s='';
    if($options!=null) foreach($options as $id=>$opt) $s.="$id=$opt ";
    return $s;
  }
} //end class

?>