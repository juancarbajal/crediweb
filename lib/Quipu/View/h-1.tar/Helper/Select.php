<?php
require_once 'Zend/View/Helper/FormElement.php';
class Quipu_View_Helper_Select extends Zend_View_Helper_FormElement{
	function GetStrOptions($Options){
		$s='';
		if($Options!=null) foreach($Options as $id=>$opt) $s.="$id=$opt ";
		return $s;
	}
	function select($Name,$Lists,$Values=null,$Select=null,$Options=null){
		$Options['dojoType']="'dijit.form.FilteringSelect'";
		$Options['autocomplete']="'true'";
		if (is_string($Lists)){ //Usando JSON
			$s="<div dojoType='dojo.data.ItemFileReadStore' jsId='{$Name}Store' url='$Lists' style='display:none'></div>";
			$Options['store']="'{$Name}Store'";
			//$Options['dataProviderClass']="'dojo.data.ItemFileReadStore'";
			//$Options['labelAttr']="'$Values'";
			$Options['searchAttr']="'$Values'";
			$s.=$this->view->input($Name,null,$Options);
		}
		if (is_array($Lists)){
			$s="<select name=\"$Name\" id=\"$Name\" ".$this->GetStrOptions($Options).">\n";
			$Values=($Values==null)?$Lists:$Values;
			foreach($Lists as $i=>$List){
				if ($Select!=null && $Values[$i]==$Select) $s.="<option value=\"".$Values[$i]."\"  selected>".$List."</option>";
				else $s.="<option value=\"".$Values[$i]."\" >".$List."</option>";
			}
			$s.="</select>";
		}
		return $s;
	}
}
?>