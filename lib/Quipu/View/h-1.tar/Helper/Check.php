<?php
Zend_Loader::loadClass("Quipu_View_Helper_FormElement");
/**
 * @category Quipu
 * @package Quipu_View_Helper_FormElement
 * @copyright Copyright (c) 2008 Juan Carbajal
 * @license BSD License
 */
class Quipu_View_Helper_Check extends Quipu_View_Helper_FormElement{
  /**
   * CheckBox
   * @param string $name Nombre
   * @param array $list Lista de labels
   * @param array $value Lista de valores
   * @param smallint $checked Indicaci�n de marcado del checkbox
   * @param array $options Lista de opciones adicionales
   * @return string Checkbox
   */
  function check($name,$list,$value,$checked=0,$options=null){
    $options["value"]="'$value'";
    if ($checked==1) $options['checked']='"checked"';
    return $this->view->input($name,"checkbox",$options).$list;
  }
}
?>