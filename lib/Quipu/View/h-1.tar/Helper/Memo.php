<?php
require_once 'Zend/View/Helper/FormElement.php';
class Quipu_View_Helper_Memo extends Zend_View_Helper_FormElement{
	function GetStrOptions($Options){
		$s='';
		if($Options!=null) foreach($Options as $id=>$opt) $s.="$id=$opt ";
		return $s;
	}
	function memo($Name,$Value="\n\n",$Rows=5,$Cols=20,$Required=false,$Options=null){
		$Options['rows']="'$Rows'";
		$Options['cols']="'$Cols'";
		$Options['style']="'font-size:10px'";
		$Options['required']=($Required)?"'true'":"'false'";
		return "<textarea name=\"$Name\" id=\"$Name\" dojoType='dijit.form.Textarea' ".$this->GetStrOptions($Options).">".$Value."</textarea>";
	}
}
?>