<?php
Zend_Loader::loadClass('Quipu_View_Helper_FormElement');
/**
 * @category Quipu
 * @package Quipu_View_Helper
 * @copyright Copyright (c) 2008 Juan Carbajal
 * @license BSD License
 */
class Quipu_View_Helper_Endform extends Quipu_View_Helper_FormElement{
  /**
   * Fin de formulario
   * @return string fin de formulario HTML
   */
  function endform(){
	return '</form>';
  }
}
?>