<?php
require_once 'Zend/View/Helper/FormElement.php';
class Quipu_View_Helper_TextDate extends Zend_View_Helper_FormElement{
	function textDate($Name,$Default="",$Required=false,$MaxLength=10,$Size=12,$Options=null){
		$Options["dojoType"]="'dijit.form.DateTextBox'";
		$Options["invalidMessage"]="'Fecha Invalida. use DD/MM/YYYY.'";
		 return $this->view->text($Name,$Default,$Required,$MaxLength,$Size,$Options);
	}
}
?>