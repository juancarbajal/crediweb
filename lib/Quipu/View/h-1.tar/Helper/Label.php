<?php
require_once 'Zend/View/Helper/FormElement.php';
class Quipu_View_Helper_Label extends Zend_View_Helper_FormElement{
	function label($Value,$for,$AccessKey=null){
		if ($AccessKey==null){
			$p=strpos($Value,'<u>');//Buscamos el primer subrayado
					if ($p===false)  return "<label for='$for'>$Value</label>";
					else $AccessKey=substr($Value,$p+strlen('<ul>')-1,1);
					return "<label for='$for' accesskey='$AccessKey' >$Value</label>";
		}
		else   return "<label for='$for' accesskey='$AccessKey' >$Value</label>";
	}
}
?>