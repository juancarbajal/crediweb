<?php
require_once 'Zend/View/Helper/FormElement.php';
class Quipu_View_Helper_TextCurrency extends Zend_View_Helper_FormElement{
	function textCurrency($Name,$Default="",$Required=false,$MaxLength=10,$Size=20,$Options=null){
		$Options["dojoType"]="'CurrencyTextbox'";
		$Options["fractional"] = "'true'";
		$Options["trim"]="'true'";
		$Options["invalidMessage"]="'La moneda es invalida.'";
		//$Options["onKeyPress"]='"return '.$this->GetJSValidator().'.IsFloatInline(event);"';		
		return $this->view->text($Name,$Default,$Required,$MaxLength,$Size,$Options);
	}
}
?>