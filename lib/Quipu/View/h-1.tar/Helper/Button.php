<?php
Zend_Loader:loadClass("Quipu_View_Helper_FormElement");
/**
 * @category Quipu
 * @package Quipu_VIew_Helper_Button
 * @copyright Copyright (c) 2008 Juan Carbajal
 * @license BSD License
 */
class Quipu_View_Helper_Button extends Zend_View_Helper_FormElement{
  /**
   * Bot�n 
   * @param string $name Nombre
   * @param string $value Valor o label del bot�n
   * @param string $options Opciones adicionales
   * @param string onClick evento Javascript al hacer click
   * @uses Zend_View_Helper_FormElement::getStrOptions()
   * @return string Bot�n HTML
   */
  function button($name,$value,$onClick,$options=null){
    		$Options['onClick']="\"$onClick\"";
		//return "<button name='$Name' id='$Name'  dojoType='dijit.form.Button' ".(($Icon!=null)?"iconClass='$Icon'":'').$this->GetStrOptions($Options).">$Value</button>";
		return "<input type='button' id='$name' name='$name' value='$value' ".$this->getStrOptions($options).">";
  }
}
?>