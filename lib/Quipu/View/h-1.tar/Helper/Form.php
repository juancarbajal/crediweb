<?php
Zend_Loader::loadClass("Quipu_View_Helper_FormElement");
/**
 * @category Quipu
 * @package Quipu_View_Helper
 * @copyright Copyright (c) 2008 Juan Carbajal
 * @license BSD License
 */
class Quipu_View_Helper_Form extends Quipu_View_Helper_FormElement{
  /**
   * Funci�n que genera marca de formulario HTML
   * @param string $name Nombre del formulario
   * @param string $title T�tulo del formulario
   * @param string $action Acci�n del formulario (SCRIPT destino)
   * @param string $method M�todo de envio de formulario GET o POST
   * @param string $target Destino de respuesta
   * @param string $encode Tipo de codificaci�n de envio
   * @param string $onSubmit Funci�n Javascript que se ejecuta al enviar el formulario
   * @return string marca de formulario HTML
   */
  function form($name,$title='',$action='',$method='post',$target='_self',$encode='application/x-www-form-urlencoded', $onSubmit=''){
    $s="<caption>$title</caption><form name='$name' id='$name' ".(($action!='')?"action='$action'":'')." method='$method'  target='$target' enctype='$encode' ".(($onSubmit!='')?"onSubmit='$onSubmit'":'').">";
    return $s;
    //action='$action'
  }
}
?>