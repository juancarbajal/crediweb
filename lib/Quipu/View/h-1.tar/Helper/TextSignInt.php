<?php
require_once 'Zend/View/Helper/FormElement.php';
class Quipu_View_Helper_TextSignInt extends Zend_View_Helper_FormElement{
	function textSignInt($Name,$Default="",$Reload="",$Required=false,$MaxLength=10,$Size=20,$Options=null){
		$Options["signed"]="'true'";
		return $this->view->textInt($Name,$Default,$Reload,$Required,$MaxLength,$Size,$Options);
	}
}
?>